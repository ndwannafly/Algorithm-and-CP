#include <bits/stdc++.h>
using namespace std;
template <typename T> inline void read(T &x){
    bool nega=0;
    char c;
    while((!isdigit(c=getchar()))&&(c!='-'));
    if(c=='-'){
        nega=1;
        c=getchar();
    }
    x=c-48;
    while(isdigit(c=getchar())) x=x*10+c-48;
    if(nega) x=-x;
}
template <typename T> inline void writep(T x){
    if(x>9) writep(x/10);
    putchar(x%10+48);
}
template <typename T> inline void write(T x){
    if(x<0){
        x=-x;
        putchar('-');
    }
    writep(x);
}
template <typename T> inline void writeln(T x){
    write(x);
    putchar('\n');
}
typedef long long ll;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;
#define NMAX 300005
#define pb push_back
const ll base=1e9+7;
//ax+by+c=0;
// y=-c/b-a/b*x
int n;
struct line{
    ll a,b,c;
}L[NMAX];
map <pll,ll> cnt;
ll sum;
int main(){
    freopen("NUMTRIAN.inp","r",stdin);
    freopen("NUMTRIAN.out","w",stdout);
    read(n);
    for(int i=1;i<=n;i++){
        read(L[i].a);
        read(L[i].b);
        read(L[i].c);
        ll g=__gcd(L[i].a,L[i].b);
        L[i].a/=g;
        L[i].b/=g;
        cnt[{L[i].a,L[i].b}]++;
    }
    for(map<pll,ll> ::iterator it=cnt.begin();it!=cnt.end();it++){
        sum+=(it->second)*(it->second-1)/2;
    }
   // cout<<"sum: "<<sum<<'\n'; // tong cac cap song song
    ll res=0;
    for(int i=1;i<=n;i++){
        ll a=L[i].a,b=L[i].b;
        ll g=__gcd(a,b);
        a/=g,b/=g;
        ll add=n-cnt[{a,b}];
        res+=add*(add-1)/2; // cac cap cat duong thang nay
        res-=(sum-cnt[{a,b}]*(cnt[{a,b}]-1)/2); // tru di cap canh song song
    }
    res/=3;
    res%=base;
    write(res);
}
