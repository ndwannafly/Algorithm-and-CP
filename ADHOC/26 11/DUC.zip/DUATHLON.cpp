#include <bits/stdc++.h>
using namespace std;
template <typename T> inline void read(T &x){
    char c;
    bool nega=0;
    while((!isdigit(c=getchar()))&&(c!='-'));
    if(c=='-'){
        nega=1;
        c=getchar();
    }
    x=c-48;
    while(isdigit(c=getchar())) x=x*10+c-48;
    if(nega) x=-x;
}
template <typename T> inline void writep(T x){
    if(x>9) writep(x/10);
    putchar(x%10+48);
}
template <typename T> inline void write(T x){
    if(x<0){
        putchar('-');
        x=-x;
    }
    writep(x);
}
template <typename T> inline void writeln(T x){
    write(x);
    putchar('\n');
}
typedef long long ll;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;
#define NMAX 100005
class{
private:
    int p[NMAX];
public:
    inline void init(){
        memset(p,-1,sizeof(p));
    }
    inline int findroot(int u){
        if(p[u]<0) return u;
        return p[u]=findroot(p[u]);
    }
    inline void Union(int u,int v){
        if(p[u]<p[v]){
            p[u]+=p[v];
            p[v]=u;
        }
        else{
            p[v]+=p[u];
            p[u]=v;
        }
    }
}DSU;
pii a[NMAX];
int b[NMAX];
int n,cnt;
bool dau,cuoi;
bool dx[NMAX];
// F nuoc G can
int main(){
    freopen("DUATHLON.inp","r",stdin);
    freopen("DUATHLON.out","w",stdout);
    read(n);
    for(int i=1;i<=n;i++){
        read(a[i].first);
        a[i].second=i;
        b[i]=a[i].first;
    }
    DSU.init();
    sort(a+1,a+n+1);
    b[0]=1e9+1,b[n+1]=1e9+1;
    int res=1;
    int water=0;
    for(int i=1;i<=n;i++){
        int l=i;
        while(a[l].first==a[i].first){
            if(a[l].second==1) dau=1;
            if(a[l].second==n) cuoi=1;
            int pos=a[l].second;
            bool flag=0;
            int upd=0;
            if(b[pos+1]<=b[pos]&&dx[pos+1]){
                int pu=DSU.findroot(pos+1);
                int pv=DSU.findroot(pos);
                if(pu!=pv) DSU.Union(pu,pv);
                flag=1;
                upd++;
                dx[pos]=1;
            }
            if(b[pos-1]<=b[pos]&&dx[pos-1]){
                int pu=DSU.findroot(pos);
                int pv=DSU.findroot(pos-1);
                if(pu!=pv) DSU.Union(pu,pv);
                flag=1;
                upd++;
                dx[pos]=1;
            }
         //   cout<<"get: "<<a[l].first<<'\n';
            if(!flag) water++;
            if(upd==2) water--;
            l++;
            dx[pos]=1;
        }
        i=l;
        i--;
        int land=water-1;
        if(!dau) land++;
        if(!cuoi) land++;
        res=max(res,land+water-1);
       // cout<<land<<" "<<water<<'\n';
       // return 0;
    }
    // 1 2 3 4
    cout<<res;
}
