#include <bits/stdc++.h>
using namespace std;
template <typename T> inline void read(T &x){
    char c;
    bool nega=0;
    while((!isdigit(c=getchar()))&&(c!='-'));
    if(c=='-'){
        nega=1;
        c=getchar();
    }
    x=c-48;
    while(isdigit(c=getchar())) x=x*10+c-48;
    if(nega) x=-x;
}
template <typename T> inline void writep(T x){
    if(x>9) writep(x/10);
    putchar(x%10+48);
}
template <typename T> inline void write(T x){
    if(x<0){
        putchar('-');
        x=-x;
    }
    writep(x);
}
template <typename T> inline void writeln(T x){
    write(x);
    putchar('\n');
}
typedef long long ll;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;
typedef long double ld;

const ld PI=2.0*acos(0.0);
#define INF 1000000000
#define pb push_back
struct points{
	ll x,y;
	points(){
	    x=y=0;
    }
	points(ll _x, ll _y) : x(_x), y(_y) {};
	bool operator == (const points &other) {
		return (x==other.x)&&(y==other.y);
	}
	inline bool operator < (const points &other){
        if(x==other.x) return y<other.y;
	}
};
ll n;
vector<points> vpoint, convex;
inline ll cross3(points &o,points &a,points &b){
	return (a.x-o.x)*(b.y-o.y)-(a.y-o.y)*(b.x-o.x);
}
void convex_hull(){
	ll t,n=(ll)vpoint.size(),k=0;
	convex.resize(2*n);
	sort(vpoint.begin(),vpoint.end());
	for(int i=0;i<n;i++){
		while(k>=2&&cross3(convex[k-2],convex[k-1],vpoint[i])<=0) k--;
		convex[k++]=vpoint[i];
	}
	for(int i=n-1,t=k+1;i>=0;i--){
		while(k>=t&&cross3(convex[k-2],convex[k-1],vpoint[i])<=0) k--;
		convex[k++]=vpoint[i];
	}
	if(convex[0]==convex[k-1]) k--;
	convex.resize(k);
}
points to_vec (points &a,points &b) {
	return points(b.x-a.x,b.y-a.y);
}
ll cross2 (const points &a, const points &b) {
	return a.x*b.y-a.y*b.x;
}
ll area (points &a,points &b,points &c) {
	return abs(cross2(to_vec(a,b),to_vec(a,c)));
}
ld max_tri(){
	ll a,b,c,ba,bb,bc,n=(ll)convex.size();
	a=ba=0;
	b=bb=1;
	c=bc=2;
	for(;a<n;a++){
		if(a==b) b=(b+1)%n;
		if(b==c) c=(c+1)%n;
		while(true){
			while(area(convex[a],convex[b],convex[c])<=area(convex[a],convex[b],convex[(c+1)%n])) c=(c+1)%n;
			if(area(convex[a],convex[b],convex[c])<=area(convex[a],convex[(b+1)%n],convex[c])){
				b=(b+1)%n;
				continue;
			} else break;
		}
		if(area(convex[a],convex[b],convex[c])>area(convex[ba],convex[bb],convex[bc])) ba=a,bb=b,bc=c;
	}
	return ((ld)area(convex[ba],convex[bb],convex[bc]))*0.5;
}

int main(){
    freopen("TRILAND.inp","r",stdin);
    freopen("TRILAND.out","w",stdout);
	cin>>n;
	for(int i=0;i<n;i++){
        ll x,y;
        cin>>x>>y;
        vpoint.pb({x,y});
	}
	convex_hull();
	cout<<setprecision(1)<<fixed<<max_tri()<<'\n';
}
